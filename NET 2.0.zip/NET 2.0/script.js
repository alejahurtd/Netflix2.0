document.addEventListener("DOMContentLoaded", function () {
    const content = document.getElementById("content");

    // banner señor de los cielos
    const movieData = {
        title: "El Señor De Los Cielos",
        rating: "4.8 Ratings",
        description: "Después de fingir su propia muerte, Aurelio ahora vive bajo una nueva identidad, pero pronto se da cuenta de que no puede escapar de su pasado y se ve obligado a volver al mundo del narcotráfico para proteger a su familia y luchar contra sus enemigos.",
        ageRating: "+17",
        playButtonImageURL: "play.png",
        saveButtonImageURL: "guardar.png",
        userImageURL: "userperson.png",
        backgroundImageURL: "https://elukelele.com/wp-content/uploads/2023/01/Estreno-de-la-octava-temporada-de-El-Senor-de-los-Cielos-como-verla-1.webp"
    };

    // poner los elementos en HTML 
    const movieContainer = document.createElement("div");
    movieContainer.classList.add("partesuperior");

    const movieHeader = document.createElement("div");
    movieHeader.classList.add("superior0");

    const navigationList = document.createElement("ul");
    navigationList.classList.add("superior1");
    navigationList.innerHTML = `
        <li><img class="menu" src="manu lineas.png" alt=""></li>
        <li>TV Shows</li>
        <li>Movies</li>
        <li>Kids</li>
    `;

    const userImage = document.createElement("img");
    userImage.classList.add("usuario");
    userImage.src = movieData.userImageURL;
    userImage.alt = "User Image";

    const movieDescription = document.createElement("div");
    movieDescription.classList.add("descripcion");
    movieDescription.innerHTML = `
        <div class="nombretitulo">
            <h1>${movieData.title}</h1>
            <h3>(${movieData.rating})</h3>
        </div>
        <div class="texto">
            <p>${movieData.description}</p>
        </div>
        <br>
        <div class="playsave">
            <button class="buttonplay"> <img src="${movieData.playButtonImageURL}" alt=""> Play</button>
            <button class="buttonsave"> <img src="${movieData.saveButtonImageURL}" alt=""> Save</button>
            <h3>${movieData.ageRating}</h3>
        </div>
    `;

    movieHeader.appendChild(navigationList);
    movieHeader.appendChild(userImage);
    movieContainer.appendChild(movieHeader);
    movieContainer.appendChild(movieDescription);
    content.appendChild(movieContainer);

    
});



// PARTE DE RECOMENDADOS

document.addEventListener("DOMContentLoaded", function () {
    const recomendadosTitle = document.createElement("h2");
    recomendadosTitle.textContent = "LOS RECOMENDADOS PARA TÍ";
    const seccionRecomendados = document.querySelector(".seccion");
    seccionRecomendados.insertBefore(recomendadosTitle, document.getElementById("seriesList"));

    // las pelis
    const seriesData = [
        {
            imageURL: "series fotos/1.jpeg",
            ratings: "Ratings",
            favorites: 5,
            saved: true,
    
        },
        {
            imageURL: "series fotos/2.jpeg",
            ratings: "Ratings",
            favorites: 4,
            saved: true,
        },
        {
            imageURL: "series fotos/3.jpeg",
            ratings: "Ratings",
            favorites: 5,
            saved: true,
        },
        {
            imageURL: "series fotos/4.jpeg",
            ratings: "Ratings",
            favorites: 3,
            saved: false,
        },
        {
            imageURL: "series fotos/5.jpeg",
            ratings: "Ratings",
            favorites: 4,
            saved: false,
        },
        {
            imageURL: "series fotos/6.jpeg",
            ratings: "Ratings",
            favorites: 5,
            saved: false,
        },
        {
            imageURL: "series fotos/7.jpeg",
            ratings: "Ratings",
            favorites: 4,
            saved: false,
        },
        {
            imageURL: "series fotos/8.jpeg",
            ratings: "Ratings",
            favorites: 4,
            saved: false,
        },
    ];

    const seriesList = document.getElementById("seriesList");


    // parte del HTML 
    seriesData.forEach((series) => {
        const listItem = document.createElement("li");

        const imageDiv = document.createElement("div");
        imageDiv.classList.add("imagen");

        const image = document.createElement("img");
        image.src = series.imageURL;
        image.alt = "Serie Imagen";

        imageDiv.appendChild(image);

        const bottomText = document.createElement("div");
        bottomText.classList.add("bottomtext");

        const stars = document.createElement("div");
        stars.classList.add("stars");
        stars.innerHTML = `<p>${series.ratings}</p>`;
        for (let i = 0; i < series.favorites; i++) {
            const starImage = document.createElement("img");
            starImage.src = "fav seleccionada.png";
            starImage.alt = "Star";
            stars.appendChild(starImage);
        }

        const guardado = document.createElement("div");
        guardado.classList.add("guardado");
        const guardadoImage = document.createElement("img");
        guardadoImage.src = series.saved ? "guardar.png" : "guardar.png";
        guardadoImage.alt = "Guardar";
        guardado.appendChild(guardadoImage);

        bottomText.appendChild(stars);
        bottomText.appendChild(guardado);

        listItem.appendChild(imageDiv);
        listItem.appendChild(bottomText);

        seriesList.appendChild(listItem);
    });
});


// PARTE TENDENCIA

document.addEventListener("DOMContentLoaded", function () {
    const tendenciasTitle = document.createElement("h2");
    tendenciasTitle.textContent = "TENDENCIAS DE LA SEMANA";
    const seccionTendencias = document.querySelectorAll(".seccion")[1]; // este[1] se coloca cuando hay varios seccion en html 
    //pero necesitamos especificar cual es, esa es la posicion 2 en html, aca viene siendo la 1. 

    seccionTendencias.insertBefore(tendenciasTitle, document.getElementById("tendenciasList"));

    // Las pelis
    const tendenciasData = [
        {
            imageURL: "series fotos/12.jpeg",
            ratings: "Ratings",
            favorites: 5,
            saved: true,
        },
        {
            imageURL: "series fotos/13.jpeg",
            ratings: "Ratings",
            favorites: 4,
            saved: true,
        },
        {
            imageURL: "series fotos/14.jpeg",
            ratings: "Ratings",
            favorites: 5,
            saved: true,
        },
        {
            imageURL: "series fotos/15.jpeg",
            ratings: "Ratings",
            favorites: 3,
            saved: false,
        },
        {
            imageURL: "series fotos/16.jpeg",
            ratings: "Ratings",
            favorites: 4,
            saved: false,
        },
        {
            imageURL: "series fotos/17.jpeg",
            ratings: "Ratings",
            favorites: 5,
            saved: false,
        },
        {
            imageURL: "series fotos/18.jpeg",
            ratings: "Ratings",
            favorites: 4,
            saved: false,
        },
        {
            imageURL: "series fotos/19.jpeg",
            ratings: "Ratings",
            favorites: 4,
            saved: false,
        }
    ];

    const tendenciasList = document.getElementById("tendenciasList");

    // crear lo de html 
    tendenciasData.forEach((tendencia) => {
        const listItem = document.createElement("li");

        const imageDiv = document.createElement("div");
        imageDiv.classList.add("imagen");

        const image = document.createElement("img");
        image.src = tendencia.imageURL;
        image.alt = "Serie Imagen";

        imageDiv.appendChild(image);

        const bottomText = document.createElement("div");
        bottomText.classList.add("bottomtext");

        const stars = document.createElement("div");
        stars.classList.add("stars");
        stars.innerHTML = `<p>${tendencia.ratings}</p>`;
        for (let i = 0; i < tendencia.favorites; i++) {
            const starImage = document.createElement("img");
            starImage.src = "fav seleccionada.png";
            starImage.alt = "Star";
            stars.appendChild(starImage);
        }

        const guardado = document.createElement("div");
        guardado.classList.add("guardado");
        const guardadoImage = document.createElement("img");
        guardadoImage.src = tendencia.saved ? "guardar.png" : "guardar.png";
        guardadoImage.alt = "Guardar";
        guardado.appendChild(guardadoImage);

        bottomText.appendChild(stars);
        bottomText.appendChild(guardado);

        listItem.appendChild(imageDiv);
        listItem.appendChild(bottomText);

        tendenciasList.appendChild(listItem);
    });
});

// banner flotante 

const banner = document.getElementById('banner');

seriesList.addEventListener('mouseover', () => {
    banner.style.display = 'block';
    banner.innerHTML = 'Me rindo';
});

seriesList.addEventListener('mouseout', () => {
    banner.style.display = 'none';
});

tendenciasList.addEventListener('mouseover', () => {
    banner.style.display = 'block';
    banner.innerHTML = 'Me rindo x2';
});

tendenciasList.addEventListener('mouseout', () => {
    banner.style.display = 'none';
});


